# GeneticRobot
A robot to robocode with genetic movement.
